var express = require('express');
var app = express(express.logger());
app.use(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
 'mongodb://josh:ihopethisworks@widmore.mongohq.com:10000/highscores';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});
 
 //post to /submit.json
app.post('/submit.json', function (request, response)
{
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");

  var game_title = request.body.game_title;
  var username = request.body.username;
  var score = request.body.score;
  var created_at = Date();
  
  var post_string = {'game_title':game_title,'username':username,'score':score,'created_at':created_at};
  db.collection('scores', function(error, collection) 
  {
    if(!error)
    {
			collection.insert(post_string);	
    }
    else
    {
      response.send("Error! Data was not saved");
    }
  });
});

//Get all data for root index
app.get('/', function(request, response, next) 
{
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");


	db.collection('scores', function(error, collection) 
  {
    if(!error)
    {
      response.set('Content-Type', 'text/json');
      collection.find().toArray(function(error, scores) 
      {
        response.send(scores);
      });
    }
    else
    {
      response.send("Error! Can't collect data");
    }
  });
});

//get top 10 highscores for a given game
app.get('/highscores.json', function(request,response,next)
{	
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");


	var game_title = request.query.game_title;
	db.collection('scores', function(error, collection)
  {
		if(!error)
    {
			response.set('Content-Type', 'text/json');
    	collection.find({'game_title':game_title}).toArray(function(error, scores)
      {
        scores.sort(function(a,b){return (parseInt(b['score'])-parseInt(a['score']))});
        var highscores = [];
        for(var i=0; i<10; i++)
        {
          if(scores[i] != null)
          {
            highscores.push(scores[i]);	
			    }
			  }
			  response.send(highscores);
      });
    }
    else
    {
      response.send("Error! Can't collect data");
    }
  });
});

app.get('/userquery', function(request, response)
{
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");


	var username = request.query.username;
	db.collection('scores', function(error, collection) 
  {
		if(!error)
    {
			response.set('Content-Type', 'text/json');
    	collection.find({"username":username}).toArray(function(error, scores)
      {
				response.send(scores);
      });
    }
    else
    {
      response.send("Error! Can't collect data");
    }
	});
})

app.get('/usersearch', function(request, response)
{ 
  response.header("Access-Control-Allow-Origin", "*");
  response.header("Access-Control-Allow-Headers", "X-Requested-With");

	response.send("<script>function displayResults(){query=document.getElementById('search').value;window.location='http://blooming-wildwood-4625.herokuapp.com/userquery?username='+query;}</script><body><label>Please enter a username to query:</label><input type='text' id='search' onchange='displayResults()'/></body>");
});

// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);

