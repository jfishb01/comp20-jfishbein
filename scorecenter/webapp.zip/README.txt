Josh Fishbein     Comp 20      Assignment 5: Score Center

All components of this project have been properly implemented. The POST and
GET APIs are implemented as requested. The root page displays all game data 
stored in the mongodb database. The usersearch page allows the client to 
search for a user by typing into an input textbox. By hitting enter, a new 
page will open where all highscores of a given user will be displayed. 
The highscores page will show the top ten highscores for a given game.

I collaborated with Ben Leiken, Garrett Friedman, Sean Harrington, Kenny Cohen, 
Emily Eng, and Scott Owades.

I spent approximately 15-20 hours on this assignment.